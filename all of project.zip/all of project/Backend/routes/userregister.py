from flask import Blueprint, jsonify, render_template, request
import mysql.connector
from mysql.connector import Error

# Create a Blueprint for user register related routes
userregister_bp = Blueprint('userregister', __name__)

# MySQL database configuration
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Tamiloos3855",
    database="bitnjoy"
)

# Route to serve the HTML page
@userregister_bp.route('/')
def index():
    return render_template('main.html')

# API route to fetch data from MySQL and return it as JSON
@userregister_bp.route('/userregister')
def userregister():
    cursor = db.cursor()
    cursor.execute("SELECT * FROM tbl_userregister")
    result = cursor.fetchall()
    
    data = [dict(zip([column[0] for column in cursor.description], row)) for row in result]
    return render_template('userregister.html', data=data)

# API route to handle adding new user register
@userregister_bp.route('/api/add_userregister', methods=['POST'])
def add_userregister():
    try:
        # Extract data from the incoming request (JSON payload)
        data = request.get_json()
        
        # Get values from the JSON request
        GUID = data.get('field1')
        cellNumber = data.get('field2')
        verificationTypeID = data.get('field3')
        IP = data.get('field4')
        dateTime = data.get('field5')
        description = data.get('field6')
        status = data.get('field7')
        
        # Insert the new entry into the database
        cursor = db.cursor()
        query = "INSERT INTO tbl_userregister (GUID, CellNumber, VerificationTypeID, IP,\
                    DateTime, Description, Status) VALUES (%s, %s, %s, %s, %s, %s, %s)"
        cursor.execute(query, (GUID, cellNumber, verificationTypeID, IP, dateTime, \
            description, status))
        db.commit()
        
        return jsonify({"message": "User register added successfully!"}), 201
    
    except Error as e:
        return jsonify({"error": str(e)}),400

# API route to handle deleting a user register by ID
@userregister_bp.route('/api/delete_userregister/<int:id>', methods=['DELETE'])
def delete_userregister(id):
    try:
        # Create a cursor
        cursor = db.cursor()

        # Execute the DELETE query
        query = "DELETE FROM tbl_userregister WHERE id = %s"
        cursor.execute(query, (id,))
        db.commit()

        # Check if the row was actually deleted
        if cursor.rowcount == 0:
            return jsonify({"message": "No record found with the provided ID"}), 404

        return jsonify({"message": "User register deleted successfully!"}), 200

    except Error as e:
        return jsonify({"error": str(e)}), 500

# API route to fetch userregister by ID
@userregister_bp.route('/api/get_userregister/<int:id>', methods=['GET'])
def get_userregister(id):
    try:
        cursor = db.cursor(dictionary=True)
        cursor.execute("SELECT * FROM tbl_userregister WHERE id = %s", (id,))
        result = cursor.fetchone()

        if result:
            return jsonify(result), 200
        else:
            return jsonify({"error": "Record not found"}), 404

    except Error as e:
        return jsonify({"error": str(e)}), 500

# API route to handle modifying a userregister
@userregister_bp.route('/api/modify_userregister/<int:id>', methods=['PUT'])
def modify_userregister(id):
    try:
        # Extract data from the request
        data = request.get_json()

        # guid = data.get('field1')
        cellNumber = data.get('field2')
        verificationTypeID = data.get('field3')
        # ip = data.get('field4')
        # dateTime = data.get('field5')
        description = data.get('field6')
        status = data.get('field7')

        # Update the database record
        cursor = db.cursor()
        query = "UPDATE tbl_userregister SET CellNumber = %s, VerificationTypeID = %s, Description = %s, Status = %s WHERE id = %s"
        cursor.execute(query, (cellNumber, verificationTypeID, description, status, id))
        db.commit()

        if cursor.rowcount == 0:
            return jsonify({"message": "Don't want to change? So select Cancel button."}), 404

        return jsonify({"message": "User register updated successfully!"}), 200

    except Error as e:
        print("Database Error:", e)
        return jsonify({"error": f"Database Error: {str(e)}"}), 500
    
