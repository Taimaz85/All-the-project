from flask import Blueprint, jsonify, render_template, request
import mysql.connector
from mysql.connector import Error


# Create a Blueprint for additional amount related routes
additionalamount_bp = Blueprint('additionalamount', __name__)

# MySQL database configuration
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Tamiloos3855",
    database="bitnjoy"
)

# Route to serve the HTML page
@additionalamount_bp.route('/')
def index():
    return render_template('main.html')

# API route to fetch data from MySQL and return it as JSON
@additionalamount_bp.route('/additionalamount')
def additionalamount():
    cursor = db.cursor()
    cursor.execute("SELECT * FROM tbl_additionalamount")
    result = cursor.fetchall()
    
    data = [dict(zip([column[0] for column in cursor.description], row)) for row in result]
    return render_template('additionalamount.html', data=data)

# API route to handle adding new additional amount
@additionalamount_bp.route('/api/add_additionalamount', methods=['POST'])
def add_additionalamount():
    try:
        # Extract data from the incoming request (JSON payload)
        data = request.get_json()
        
        # Get values from the JSON request
        name = data.get('field1')
        amountCalculationTypeID = data.get('field2')
        amount = data.get('field3')
        description = data.get('field4')
        status = data.get('field5')
        
        # Insert the new entry into the database
        cursor = db.cursor()
        query = "INSERT INTO tbl_additionalamount (Name, AmountCalculationTypeID, Amount, Description, Status)\
            VALUES (%s, %s, %s, %s, %s)"
        cursor.execute(query, (name, amountCalculationTypeID, amount, description, status))
        db.commit()
        
        return jsonify({"message": "Additional amount added successfully!"})
    
    except Error as e:
        return jsonify({"error": str(e)}),400
    
# API route to handle deleting a additional amount by ID
@additionalamount_bp.route('/api/delete_additionalamount/<int:id>', methods=['DELETE'])
def delete_additionalamount(id):
    try:
        # Create a cursor
        cursor = db.cursor()

        # Execute the DELETE query
        query = "DELETE FROM tbl_additionalamount WHERE id = %s"
        cursor.execute(query, (id,))
        db.commit()

        # Check if the row was actually deleted
        if cursor.rowcount == 0:
            return jsonify({"message": "No record found with the provided ID"}), 404

        return jsonify({"message": "Additional amount deleted successfully!"}), 200

    except Error as e:
        return jsonify({"error": str(e)}), 500

# API route to fetch additional amount by ID
@additionalamount_bp.route('/api/get_additionalamount/<int:id>', methods=['GET'])
def get_additionalamount(id):
    try:
        cursor = db.cursor(dictionary=True)
        cursor.execute("SELECT * FROM tbl_additionalamount WHERE id = %s", (id,))
        result = cursor.fetchone()

        if result:
            return jsonify(result), 200
        else:
            return jsonify({"error": "Record not found"}), 404

    except Error as e:
        return jsonify({"error": str(e)}), 500

# API route to handle modifying a additional amount
@additionalamount_bp.route('/api/modify_additionalamount/<int:id>', methods=['PUT'])
def modify_additionalamount(id):
    try:
        # Extract data from the request
        data = request.get_json()

        name = data.get('field1')
        amountCalculationTypeID = data.get('field2')
        amount = data.get('field3')
        description = data.get('field4')
        status = data.get('field5')

        # Update the database record
        cursor = db.cursor()
        query = "UPDATE tbl_additionalamount SET Name = %s, AmountCalculationTypeID = %s,\
            Amount = %s, Description = %s, Status = %s WHERE id = %s"
        cursor.execute(query, (name , amountCalculationTypeID, amount, description, status, id))
        db.commit()

        if cursor.rowcount == 0:
            return jsonify({"message": "No record found with the provided ID"}), 404

        return jsonify({"message": "Additional Amount updated successfully!"}), 200

    except Error as e:
        return jsonify({"error": str(e)}), 500
    
