from flask import Blueprint, jsonify, render_template, request
import mysql.connector
from mysql.connector import Error


# Create a Blueprint for currency type related routes
currencytype_bp = Blueprint('currencytype', __name__)

# MySQL database configuration
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Tamiloos3855",
    database="bitnjoy"
)

# Route to serve the HTML page
@currencytype_bp.route('/')
def index():
    return render_template('main.html')

# API route to fetch data from MySQL and return it as JSON
@currencytype_bp.route('/currencytype')
def currencytype():
    cursor = db.cursor()
    cursor.execute("SELECT * FROM tbl_currencytype")
    result = cursor.fetchall()
    
    data = [dict(zip([column[0] for column in cursor.description], row)) for row in result]
    return render_template('currencytype.html', data=data)

# API route to handle adding new currency type
@currencytype_bp.route('/api/add_currencytype', methods=['POST'])
def add_currencytype():
    try:
        # Extract data from the incoming request (JSON payload)
        data = request.get_json()
        
        # Get values from the JSON request
        name = data.get('field1')
        currencyCode = data.get('field2')
        value = data.get('field3')
        description = data.get('field4')
        status = data.get('field5')
        
        # Insert the new entry into the database
        cursor = db.cursor()
        query = "INSERT INTO tbl_currencytype (Name, CurrencyCode, Value, Description, Status) VALUES\
            (%s, %s, %s, %s, %s)"
        cursor.execute(query, (name, currencyCode, value, description, status))
        db.commit()
        
        return jsonify({"message": "Currency Type added successfully!"})
    
    except Error as e:
        return jsonify({"error": str(e)}),400
    
# API route to handle deleting a currency type by ID
@currencytype_bp.route('/api/delete_currencytype/<int:id>', methods=['DELETE'])
def delete_currencytype(id):
    try:
        # Create a cursor
        cursor = db.cursor()

        # Execute the DELETE query
        query = "DELETE FROM tbl_currencytype WHERE id = %s"
        cursor.execute(query, (id,))
        db.commit()

        # Check if the row was actually deleted
        if cursor.rowcount == 0:
            return jsonify({"message": "No record found with the provided ID"}), 404

        return jsonify({"message": "Currency Type deleted successfully!"}), 200

    except Error as e:
        return jsonify({"error": str(e)}), 500

# API route to fetch currencytype by ID
@currencytype_bp.route('/api/get_currencytype/<int:id>', methods=['GET'])
def get_currencytype(id):
    try:
        cursor = db.cursor(dictionary=True)
        cursor.execute("SELECT * FROM tbl_currencytype WHERE id = %s", (id,))
        result = cursor.fetchone()

        if result:
            return jsonify(result), 200
        else:
            return jsonify({"error": "Record not found"}), 404

    except Error as e:
        return jsonify({"error": str(e)}), 500

# API route to handle modifying a currencytype
@currencytype_bp.route('/api/modify_currencytype/<int:id>', methods=['PUT'])
def modify_currencytype(id):
    try:
        # Extract data from the request
        data = request.get_json()

        name = data.get('field1')
        currencycode = data.get('field2')
        value = data.get('field3')
        description = data.get('field4')
        status = data.get('field5')

        # Update the database record
        cursor = db.cursor()
        query = "UPDATE tbl_currencytype SET Name = %s, CurrencyCode = %s, Value = %s,\
            Description = %s, Status = %s WHERE id = %s"
        cursor.execute(query, (name, currencycode, value, description, status, id))
        db.commit()

        if cursor.rowcount == 0:
            return jsonify({"message": "No record found with the provided ID"}), 404

        return jsonify({"message": "Currency type updated successfully!"}), 200

    except Error as e:
        return jsonify({"error": str(e)}), 500
    