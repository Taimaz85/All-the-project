from flask import Blueprint, jsonify, render_template, request
import mysql.connector
from mysql.connector import Error


# Create a Blueprint for user related routes
brand_bp = Blueprint('brand', __name__)

# MySQL database configuration
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Tamiloos3855",
    database="bitnjoy"
)

# Route to serve the HTML page
@brand_bp.route('/')
def index():
    return render_template('main.html')

# API route to fetch data from MySQL and return it as JSON
@brand_bp.route('/brand')
def brand():
    cursor = db.cursor()
    cursor.execute("SELECT * FROM tbl_brandname")
    result = cursor.fetchall()
    
    data = [dict(zip([column[0] for column in cursor.description], row)) for row in result]
    return render_template('brand.html', data=data)

# API route to handle adding new brand
@brand_bp.route('/api/add_brand', methods=['POST'])
def add_brand():
    try:
        # Extract data from the incoming request (JSON payload)
        data = request.get_json()
        
        # Get values from the JSON request
        name = data.get('field1')
        description = data.get('field2')
        status = data.get('field3')
        
        # Insert the new entry into the database
        cursor = db.cursor()
        query = "INSERT INTO tbl_brandname (name, description, status) VALUES (%s, %s, %s)"
        cursor.execute(query, (name, description, status))
        db.commit()
        
        return jsonify({"message": "Brand name added successfully!"})
    
    except Error as e:
        return jsonify({"error": str(e)}),400
    
# API route to fetch brand by ID
@brand_bp.route('/api/get_brand/<int:id>', methods=['GET'])
def get_brand(id):
    try:
        cursor = db.cursor(dictionary=True)
        cursor.execute("SELECT * FROM tbl_brandname WHERE id = %s", (id,))
        result = cursor.fetchone()

        if result:
            return jsonify(result), 200
        else:
            return jsonify({"error": "Record not found"}), 404

    except Error as e:
        return jsonify({"error": str(e)}), 500

# API route to handle modifying a brand
@brand_bp.route('/api/modify_brand/<int:id>', methods=['PUT'])
def modify_brand(id):
    try:
        # Extract data from the request
        data = request.get_json()

        name = data.get('field1')
        description = data.get('field2')
        status = data.get('field3')

        # Update the database record
        cursor = db.cursor()
        query = "UPDATE tbl_brandname SET Name = %s, Description = %s, Status = %s WHERE id = %s"
        cursor.execute(query, (name, description, status, id))
        db.commit()

        if cursor.rowcount == 0:
            return jsonify({"message": "No record found with the provided ID"}), 404

        return jsonify({"message": "Brand updated successfully!"}), 200

    except Error as e:
        return jsonify({"error": str(e)}), 500
    