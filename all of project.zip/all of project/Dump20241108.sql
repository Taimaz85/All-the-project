-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: bitnjoy
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_additionalamount`
--

DROP TABLE IF EXISTS `tbl_additionalamount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_additionalamount` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) NOT NULL,
  `AmountCalculationTypeID` int NOT NULL,
  `Amount` double NOT NULL,
  `Description` text,
  `Status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `AmountCalculationTypeID` (`AmountCalculationTypeID`),
  CONSTRAINT `tbl_additionalamount_ibfk_1` FOREIGN KEY (`AmountCalculationTypeID`) REFERENCES `tbl_amountcalculationtype` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_additionalamount`
--

LOCK TABLES `tbl_additionalamount` WRITE;
/*!40000 ALTER TABLE `tbl_additionalamount` DISABLE KEYS */;
INSERT INTO `tbl_additionalamount` VALUES (1,'Shipping',1,15,'Shipping in EURO',1),(2,'Donate',2,15,'Charity in EURO',1),(4,'TAX',4,27,'VAT TAX in percent',1);
/*!40000 ALTER TABLE `tbl_additionalamount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_amountcalculationtype`
--

DROP TABLE IF EXISTS `tbl_amountcalculationtype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_amountcalculationtype` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) DEFAULT NULL,
  `CurrencyTypeID` int DEFAULT NULL,
  `Value` double NOT NULL,
  `Description` text,
  `Status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `CurrencyTypeID` (`CurrencyTypeID`),
  CONSTRAINT `tbl_amountcalculationtype_ibfk_1` FOREIGN KEY (`CurrencyTypeID`) REFERENCES `tbl_currencytype` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_amountcalculationtype`
--

LOCK TABLES `tbl_amountcalculationtype` WRITE;
/*!40000 ALTER TABLE `tbl_amountcalculationtype` DISABLE KEYS */;
INSERT INTO `tbl_amountcalculationtype` VALUES (1,'National Day Discount',1,20,'in percent',1),(2,'Christmas',2,2.5,'in Euro currency',1),(4,'Black Friday',2,40,'value in percent',1);
/*!40000 ALTER TABLE `tbl_amountcalculationtype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_brandname`
--

DROP TABLE IF EXISTS `tbl_brandname`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_brandname` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) DEFAULT NULL,
  `Description` text,
  `Status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_brandname`
--

LOCK TABLES `tbl_brandname` WRITE;
/*!40000 ALTER TABLE `tbl_brandname` DISABLE KEYS */;
INSERT INTO `tbl_brandname` VALUES (1,'BitNJoy','Processed meat manufacturing company',1),(2,'Test2','Test1 desc',1);
/*!40000 ALTER TABLE `tbl_brandname` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_comment`
--

DROP TABLE IF EXISTS `tbl_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_comment` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `UserID` int NOT NULL,
  `Comment` text,
  `Vote` int DEFAULT NULL,
  `DateTime` datetime DEFAULT NULL,
  `Description` text,
  `Status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `UserID` (`UserID`),
  CONSTRAINT `tbl_comment_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `tbl_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_comment`
--

LOCK TABLES `tbl_comment` WRITE;
/*!40000 ALTER TABLE `tbl_comment` DISABLE KEYS */;
INSERT INTO `tbl_comment` VALUES (1,3,'First Comment',5,'1990-02-02 00:00:00','first description',0);
/*!40000 ALTER TABLE `tbl_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_currencyparityrate`
--

DROP TABLE IF EXISTS `tbl_currencyparityrate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_currencyparityrate` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `FirstCurrencyID` int NOT NULL,
  `SecondCurrencyID` int NOT NULL,
  `Rate` decimal(10,0) NOT NULL,
  `UpdateDateTime` datetime NOT NULL,
  `Description` text,
  `Status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FirstCurrencyID` (`FirstCurrencyID`),
  KEY `SecondCurrencyID` (`SecondCurrencyID`),
  CONSTRAINT `tbl_currencyparityrate_ibfk_1` FOREIGN KEY (`FirstCurrencyID`) REFERENCES `tbl_currencytype` (`ID`),
  CONSTRAINT `tbl_currencyparityrate_ibfk_2` FOREIGN KEY (`SecondCurrencyID`) REFERENCES `tbl_currencytype` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_currencyparityrate`
--

LOCK TABLES `tbl_currencyparityrate` WRITE;
/*!40000 ALTER TABLE `tbl_currencyparityrate` DISABLE KEYS */;
INSERT INTO `tbl_currencyparityrate` VALUES (1,1,2,0,'2024-10-10 00:00:00','HUF to USD',0);
/*!40000 ALTER TABLE `tbl_currencyparityrate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_currencytype`
--

DROP TABLE IF EXISTS `tbl_currencytype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_currencytype` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) DEFAULT NULL,
  `CurrencyCode` varchar(10) DEFAULT NULL,
  `Value` double DEFAULT NULL,
  `Description` text,
  `Status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_currencytype`
--

LOCK TABLES `tbl_currencytype` WRITE;
/*!40000 ALTER TABLE `tbl_currencytype` DISABLE KEYS */;
INSERT INTO `tbl_currencytype` VALUES (1,'Hungarian Forint','HUF',350,'ٍquivalent to one US Dollar',1),(2,'Euro','EUR',0.9,'ٍquivalent to one US Dollar',1),(3,'United States Dollar','USD',1,'',1),(4,'test1','tst1',0.02,'test1 desc',0),(6,'Rials','IRL',698500,'equivalent to one US Dollar',1);
/*!40000 ALTER TABLE `tbl_currencytype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_discountamount`
--

DROP TABLE IF EXISTS `tbl_discountamount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_discountamount` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) NOT NULL,
  `AmountCalculationTypeID` int NOT NULL,
  `Amount` double NOT NULL,
  `Description` text,
  `Status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `AmountCalculationTypeID` (`AmountCalculationTypeID`),
  CONSTRAINT `tbl_discountamount_ibfk_1` FOREIGN KEY (`AmountCalculationTypeID`) REFERENCES `tbl_amountcalculationtype` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_discountamount`
--

LOCK TABLES `tbl_discountamount` WRITE;
/*!40000 ALTER TABLE `tbl_discountamount` DISABLE KEYS */;
INSERT INTO `tbl_discountamount` VALUES (1,'Christmas Discount',1,2,'in EURO',1),(2,'Halloween',1,20,'In Percent',1),(4,'Black Friday test',1,55,'percentage',1);
/*!40000 ALTER TABLE `tbl_discountamount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_foodstuff`
--

DROP TABLE IF EXISTS `tbl_foodstuff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_foodstuff` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `UserID` int NOT NULL,
  `Name` varchar(50) NOT NULL,
  `PictureURL` text,
  `MineralID` int DEFAULT NULL,
  `MineralQuantity` double DEFAULT NULL,
  `MineralWeightTypeID` int DEFAULT NULL,
  `VitaminID` int DEFAULT NULL,
  `VitaminQuantity` double DEFAULT NULL,
  `VitaminWeightTypeID` int DEFAULT NULL,
  `Calorie` int DEFAULT NULL,
  `Description` text,
  `Status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `UserID` (`UserID`),
  KEY `MineralID` (`MineralID`),
  KEY `MineralWeightTypeID` (`MineralWeightTypeID`),
  KEY `VitaminID` (`VitaminID`),
  KEY `VitaminWeightTypeID` (`VitaminWeightTypeID`),
  CONSTRAINT `tbl_foodstuff_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `tbl_user` (`ID`),
  CONSTRAINT `tbl_foodstuff_ibfk_2` FOREIGN KEY (`MineralID`) REFERENCES `tbl_mineral` (`ID`),
  CONSTRAINT `tbl_foodstuff_ibfk_3` FOREIGN KEY (`MineralWeightTypeID`) REFERENCES `tbl_weighttype` (`ID`),
  CONSTRAINT `tbl_foodstuff_ibfk_4` FOREIGN KEY (`VitaminID`) REFERENCES `tbl_vitamin` (`ID`),
  CONSTRAINT `tbl_foodstuff_ibfk_5` FOREIGN KEY (`VitaminWeightTypeID`) REFERENCES `tbl_weighttype` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_foodstuff`
--

LOCK TABLES `tbl_foodstuff` WRITE;
/*!40000 ALTER TABLE `tbl_foodstuff` DISABLE KEYS */;
INSERT INTO `tbl_foodstuff` VALUES (1,3,'Pickle','www.picture.com/pickle',1,0.02,1,1,0.45,1,25,'test1 desc',1),(2,3,'Onion','www.picture.com/onion.jpg',1,0.48,1,1,1.08,1,8,'test2 desc',1),(4,3,'Goda Cheese','https://dfwblobstorage.blob.core.windows.net/ewcmediacontainer/eatwisconsincheese/media/content/cheesemasters-2019/gouda-header_2.jpg',1,0.22,1,1,0.092,1,255,'This is a delicious yellow cheese',1);
/*!40000 ALTER TABLE `tbl_foodstuff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_language`
--

DROP TABLE IF EXISTS `tbl_language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_language` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(30) DEFAULT NULL,
  `FlagURL` text,
  `Unicode` varchar(30) NOT NULL,
  `Description` text,
  `Status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_language`
--

LOCK TABLES `tbl_language` WRITE;
/*!40000 ALTER TABLE `tbl_language` DISABLE KEYS */;
INSERT INTO `tbl_language` VALUES (1,'Magyar','https://www.worldometers.info/img/flags/hu-flag.gif','HUN','Hungarian Language',1),(2,'English','https://www.worldometers.info/img/flags/uk-flag.gif','ENG','English Language',1),(3,'Germany','https://www.worldometers.info/img/flags/gm-flag.gif','DE','German language',0);
/*!40000 ALTER TABLE `tbl_language` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_manufacturingcompany`
--

DROP TABLE IF EXISTS `tbl_manufacturingcompany`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_manufacturingcompany` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) DEFAULT NULL,
  `Tell` varchar(14) DEFAULT NULL,
  `Address` varchar(60) DEFAULT NULL,
  `Description` text,
  `Status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_manufacturingcompany`
--

LOCK TABLES `tbl_manufacturingcompany` WRITE;
/*!40000 ALTER TABLE `tbl_manufacturingcompany` DISABLE KEYS */;
INSERT INTO `tbl_manufacturingcompany` VALUES (1,'BitNJoy','+36205413723','Hungary, Budapest','',1);
/*!40000 ALTER TABLE `tbl_manufacturingcompany` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_mineral`
--

DROP TABLE IF EXISTS `tbl_mineral`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_mineral` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) NOT NULL,
  `Description` text,
  `Status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_mineral`
--

LOCK TABLES `tbl_mineral` WRITE;
/*!40000 ALTER TABLE `tbl_mineral` DISABLE KEYS */;
INSERT INTO `tbl_mineral` VALUES (1,'Zink','',1),(2,'Sodium','Sodium helps the body keep fluids in a normal balance (see About Body Water). Sodium plays a key role in normal nerve and muscle function.',1);
/*!40000 ALTER TABLE `tbl_mineral` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_order`
--

DROP TABLE IF EXISTS `tbl_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_order` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `UserID` int NOT NULL,
  `ProductID` int NOT NULL,
  `WeightTypeID` int NOT NULL,
  `ProductWeightAmount` int NOT NULL,
  `ProductPrice` double NOT NULL,
  `CurrencyTypeID` int NOT NULL,
  `DiscountAmountID` int NOT NULL,
  `AdditionalAmountID` int NOT NULL,
  `TotalAmount` double NOT NULL,
  `PaymentTypeID` int NOT NULL,
  `PaymentVerificationTypeID` int NOT NULL,
  `TransactionTrackingCode` varchar(30) DEFAULT NULL,
  `OrderDateTime` datetime NOT NULL,
  `ReceivingDateTime` datetime NOT NULL,
  `Description` text,
  `Status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `UserID` (`UserID`),
  KEY `ProductID` (`ProductID`),
  KEY `WeightTypeID` (`WeightTypeID`),
  KEY `CurrencyTypeID` (`CurrencyTypeID`),
  KEY `DiscountAmountID` (`DiscountAmountID`),
  KEY `AdditionalAmountID` (`AdditionalAmountID`),
  KEY `PaymentTypeID` (`PaymentTypeID`),
  KEY `PaymentVerificationTypeID` (`PaymentVerificationTypeID`),
  CONSTRAINT `tbl_order_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `tbl_user` (`ID`),
  CONSTRAINT `tbl_order_ibfk_2` FOREIGN KEY (`ProductID`) REFERENCES `tbl_productinfo` (`ID`),
  CONSTRAINT `tbl_order_ibfk_3` FOREIGN KEY (`WeightTypeID`) REFERENCES `tbl_weighttype` (`ID`),
  CONSTRAINT `tbl_order_ibfk_4` FOREIGN KEY (`CurrencyTypeID`) REFERENCES `tbl_currencytype` (`ID`),
  CONSTRAINT `tbl_order_ibfk_5` FOREIGN KEY (`DiscountAmountID`) REFERENCES `tbl_discountamount` (`ID`),
  CONSTRAINT `tbl_order_ibfk_6` FOREIGN KEY (`AdditionalAmountID`) REFERENCES `tbl_additionalamount` (`ID`),
  CONSTRAINT `tbl_order_ibfk_7` FOREIGN KEY (`PaymentTypeID`) REFERENCES `tbl_paymenttype` (`ID`),
  CONSTRAINT `tbl_order_ibfk_8` FOREIGN KEY (`PaymentVerificationTypeID`) REFERENCES `tbl_verificationtype` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_order`
--

LOCK TABLES `tbl_order` WRITE;
/*!40000 ALTER TABLE `tbl_order` DISABLE KEYS */;
INSERT INTO `tbl_order` VALUES (1,3,1,1,150,890,1,1,1,890,1,1,'1111','2024-10-10 00:00:00','2024-10-20 00:00:00','test desc',0),(4,3,1,1,500,250,1,1,1,500,1,1,'0123','2024-10-10 00:00:00','2024-11-11 00:00:00','test222',1);
/*!40000 ALTER TABLE `tbl_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_paymenttype`
--

DROP TABLE IF EXISTS `tbl_paymenttype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_paymenttype` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Value` varchar(30) DEFAULT NULL,
  `Description` text,
  `Status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_paymenttype`
--

LOCK TABLES `tbl_paymenttype` WRITE;
/*!40000 ALTER TABLE `tbl_paymenttype` DISABLE KEYS */;
INSERT INTO `tbl_paymenttype` VALUES (1,'Bank transfer','transferring money from a bank account to another bank account',1),(2,'Cash','Transferring money in cash',1);
/*!40000 ALTER TABLE `tbl_paymenttype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_productinfo`
--

DROP TABLE IF EXISTS `tbl_productinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_productinfo` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `ProductParentID` int NOT NULL,
  `Name` varchar(70) NOT NULL,
  `BrandNameID` int NOT NULL,
  `ManufacturingCompanyID` int NOT NULL,
  `MeatPercentage` int DEFAULT NULL,
  `Weight` int NOT NULL,
  `WeightTypeID` int NOT NULL,
  `Price` double NOT NULL,
  `CurrencyTypeID` int NOT NULL,
  `HealthRate` int DEFAULT NULL,
  `ProduceDate` datetime DEFAULT NULL,
  `ExpireDate` date DEFAULT NULL,
  `Stock` int DEFAULT NULL,
  `ImageURL` text,
  `CommentID` int DEFAULT NULL,
  `Rate` int DEFAULT NULL,
  `Description` text,
  `Status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ProductParentID` (`ProductParentID`),
  KEY `BrandNameID` (`BrandNameID`),
  KEY `ManufacturingCompanyID` (`ManufacturingCompanyID`),
  KEY `WeightTypeID` (`WeightTypeID`),
  KEY `CurrencyTypeID` (`CurrencyTypeID`),
  KEY `CommentID` (`CommentID`),
  CONSTRAINT `tbl_productinfo_ibfk_1` FOREIGN KEY (`ProductParentID`) REFERENCES `tbl_productparent` (`ID`),
  CONSTRAINT `tbl_productinfo_ibfk_2` FOREIGN KEY (`BrandNameID`) REFERENCES `tbl_brandname` (`ID`),
  CONSTRAINT `tbl_productinfo_ibfk_3` FOREIGN KEY (`ManufacturingCompanyID`) REFERENCES `tbl_manufacturingcompany` (`ID`),
  CONSTRAINT `tbl_productinfo_ibfk_4` FOREIGN KEY (`WeightTypeID`) REFERENCES `tbl_weighttype` (`ID`),
  CONSTRAINT `tbl_productinfo_ibfk_5` FOREIGN KEY (`CurrencyTypeID`) REFERENCES `tbl_currencytype` (`ID`),
  CONSTRAINT `tbl_productinfo_ibfk_6` FOREIGN KEY (`CommentID`) REFERENCES `tbl_comment` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_productinfo`
--

LOCK TABLES `tbl_productinfo` WRITE;
/*!40000 ALTER TABLE `tbl_productinfo` DISABLE KEYS */;
INSERT INTO `tbl_productinfo` VALUES (1,1,'testname',1,1,90,1,2,590,1,5,'2024-10-10 00:00:00','2024-12-10',100,'www.picture.com/testname.jpg',1,5,'test desc',0),(4,1,'test2',1,1,80,150,2,499,1,4,'2024-02-02 00:00:00','2025-03-03',50,'www.image.com/test2.jpg',1,4,'test2',1);
/*!40000 ALTER TABLE `tbl_productinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_productparent`
--

DROP TABLE IF EXISTS `tbl_productparent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_productparent` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Value` varchar(50) DEFAULT NULL,
  `Description` text,
  `Status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_productparent`
--

LOCK TABLES `tbl_productparent` WRITE;
/*!40000 ALTER TABLE `tbl_productparent` DISABLE KEYS */;
INSERT INTO `tbl_productparent` VALUES (1,'Sausage','All kinds of Sausages','1'),(2,'Bacon','All kinds of Bacons','1'),(3,'Ham','All kinds of Hams','1'),(4,'Salami','All kinds od Salamies','1'),(5,'Processed Meat','All kinds of Processed Meats','1'),(6,'test','test des','1'),(7,'test2','desc 2','0'),(8,'test for reload','this will reload the pages ','0');
/*!40000 ALTER TABLE `tbl_productparent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_recipe`
--

DROP TABLE IF EXISTS `tbl_recipe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_recipe` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `UserID` int NOT NULL,
  `FoodName` varchar(50) NOT NULL,
  `ProductID` int NOT NULL,
  `ProductWeightTypeID` int NOT NULL,
  `ProductQuantity` int NOT NULL,
  `FoodStuffID` int NOT NULL,
  `FoodStuffWeightTypeID` int NOT NULL,
  `FoodStuffQuantity` int NOT NULL,
  `PreprationMethod` text NOT NULL,
  `PreprationTime` time NOT NULL,
  `DishSide` varchar(100) DEFAULT NULL,
  `VitaminID` int DEFAULT NULL,
  `MineralID` int DEFAULT NULL,
  `Calorie` int DEFAULT NULL,
  `CommentID` int DEFAULT NULL,
  `Description` text,
  `Status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `UserID` (`UserID`),
  KEY `ProductID` (`ProductID`),
  KEY `ProductWeightTypeID` (`ProductWeightTypeID`),
  KEY `FoodStuffID` (`FoodStuffID`),
  KEY `FoodStuffWeightTypeID` (`FoodStuffWeightTypeID`),
  KEY `VitaminID` (`VitaminID`),
  KEY `MineralID` (`MineralID`),
  CONSTRAINT `tbl_recipe_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `tbl_user` (`ID`),
  CONSTRAINT `tbl_recipe_ibfk_2` FOREIGN KEY (`ProductID`) REFERENCES `tbl_productinfo` (`ID`),
  CONSTRAINT `tbl_recipe_ibfk_3` FOREIGN KEY (`ProductWeightTypeID`) REFERENCES `tbl_weighttype` (`ID`),
  CONSTRAINT `tbl_recipe_ibfk_4` FOREIGN KEY (`FoodStuffID`) REFERENCES `tbl_foodstuff` (`ID`),
  CONSTRAINT `tbl_recipe_ibfk_5` FOREIGN KEY (`FoodStuffWeightTypeID`) REFERENCES `tbl_weighttype` (`ID`),
  CONSTRAINT `tbl_recipe_ibfk_6` FOREIGN KEY (`VitaminID`) REFERENCES `tbl_vitamin` (`ID`),
  CONSTRAINT `tbl_recipe_ibfk_7` FOREIGN KEY (`MineralID`) REFERENCES `tbl_mineral` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_recipe`
--

LOCK TABLES `tbl_recipe` WRITE;
/*!40000 ALTER TABLE `tbl_recipe` DISABLE KEYS */;
INSERT INTO `tbl_recipe` VALUES (1,3,'Pizza',1,1,1,1,2,250,'Make the onion fried','00:00:45','pepper',1,1,289,0,'This is a deliciouse pizza',1),(2,3,'Penne Pasta',1,2,250,1,2,200,'Make onions boil','00:00:35','Vegetables',1,1,320,0,'This is a perfect pasta that most of the people like that',1),(5,3,'Lasagna',1,2,300,1,2,350,'do something','00:00:50','vegetables',1,1,389,0,'test',1);
/*!40000 ALTER TABLE `tbl_recipe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_user`
--

DROP TABLE IF EXISTS `tbl_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_user` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `UserRegisterID` int NOT NULL,
  `FirstName` varchar(30) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `BirthDate` datetime NOT NULL,
  `Email` varchar(70) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Address` varchar(100) DEFAULT NULL,
  `PictureURL` text,
  `Verify` tinyint(1) NOT NULL,
  `UserStatusID` int NOT NULL,
  `UserTypeID` int NOT NULL,
  `Description` text,
  `Status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `UserRegisterID` (`UserRegisterID`),
  KEY `UserStatusID` (`UserStatusID`),
  KEY `UserTypeID` (`UserTypeID`),
  CONSTRAINT `tbl_user_ibfk_1` FOREIGN KEY (`UserRegisterID`) REFERENCES `tbl_userregister` (`ID`),
  CONSTRAINT `tbl_user_ibfk_2` FOREIGN KEY (`UserStatusID`) REFERENCES `tbl_userstatus` (`ID`),
  CONSTRAINT `tbl_user_ibfk_3` FOREIGN KEY (`UserTypeID`) REFERENCES `tbl_usertype` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_user`
--

LOCK TABLES `tbl_user` WRITE;
/*!40000 ALTER TABLE `tbl_user` DISABLE KEYS */;
INSERT INTO `tbl_user` VALUES (3,1,'Taimaz','Lakpour','1985-06-29 00:00:00','l.taimaz85@yahoo.com','123456','Budapest 1027, Horvat ut.','picture.com/taimaz.gif',1,1,1,'test1 desc',1),(4,1,'Setty','Tah','1990-01-01 00:00:00','sety@gmail.com','123456','Budapest 1027','www.picture.com/sety',1,1,1,'test2',0),(5,1,'unknownName','unknownLastname','1990-02-02 00:00:00','unknown@gmail.com','123123','Budapest 1101','www.myunknownpicture.com/unknown',1,1,1,'test3',0);
/*!40000 ALTER TABLE `tbl_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_userregister`
--

DROP TABLE IF EXISTS `tbl_userregister`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_userregister` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `GUID` varchar(100) NOT NULL,
  `CellNumber` varchar(14) DEFAULT NULL,
  `VerificationTypeID` int NOT NULL,
  `IP` varchar(15) NOT NULL,
  `DateTime` datetime NOT NULL,
  `Description` text,
  `Status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `VerificationTypeID` (`VerificationTypeID`),
  CONSTRAINT `tbl_userregister_ibfk_1` FOREIGN KEY (`VerificationTypeID`) REFERENCES `tbl_verificationtype` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_userregister`
--

LOCK TABLES `tbl_userregister` WRITE;
/*!40000 ALTER TABLE `tbl_userregister` DISABLE KEYS */;
INSERT INTO `tbl_userregister` VALUES (1,'b21ae903-a811-4161-8104-898308292758','0036205413723',2,'176.77.139.193','2024-10-15 11:27:01','test1',0),(2,'2d7f6894-5c6d-4c72-9ee9-b383c1c9c9b8','0036101234567',1,'176.77.151.244','2024-10-15 18:11:50','test2',0),(4,'a97cd91f-03f3-4a86-a5e6-8c766aa86779','0036201233211',1,'176.77.145.8','2024-10-19 10:46:16','test2',0),(6,'5f0aa59f-2eb6-40f8-b792-7c0ad3289424','0036101233210',2,'84.225.154.200','2024-10-26 21:45:22','test desc testtest',1);
/*!40000 ALTER TABLE `tbl_userregister` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_userstatus`
--

DROP TABLE IF EXISTS `tbl_userstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_userstatus` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Value` varchar(30) NOT NULL,
  `Description` text,
  `Status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_userstatus`
--

LOCK TABLES `tbl_userstatus` WRITE;
/*!40000 ALTER TABLE `tbl_userstatus` DISABLE KEYS */;
INSERT INTO `tbl_userstatus` VALUES (1,'Active','this user is activated',1);
/*!40000 ALTER TABLE `tbl_userstatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_usertype`
--

DROP TABLE IF EXISTS `tbl_usertype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_usertype` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Value` varchar(30) NOT NULL,
  `Description` text,
  `Status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_usertype`
--

LOCK TABLES `tbl_usertype` WRITE;
/*!40000 ALTER TABLE `tbl_usertype` DISABLE KEYS */;
INSERT INTO `tbl_usertype` VALUES (1,'Normal user','adding common user',1);
/*!40000 ALTER TABLE `tbl_usertype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_verificationtype`
--

DROP TABLE IF EXISTS `tbl_verificationtype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_verificationtype` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Value` varchar(30) NOT NULL,
  `Description` text,
  `Status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_verificationtype`
--

LOCK TABLES `tbl_verificationtype` WRITE;
/*!40000 ALTER TABLE `tbl_verificationtype` DISABLE KEYS */;
INSERT INTO `tbl_verificationtype` VALUES (1,'active','This user is active',1),(2,'0','deactive',1),(3,'deactive','This user is deactive',1);
/*!40000 ALTER TABLE `tbl_verificationtype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_vitamin`
--

DROP TABLE IF EXISTS `tbl_vitamin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_vitamin` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) NOT NULL,
  `Description` text,
  `Status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_vitamin`
--

LOCK TABLES `tbl_vitamin` WRITE;
/*!40000 ALTER TABLE `tbl_vitamin` DISABLE KEYS */;
INSERT INTO `tbl_vitamin` VALUES (1,'Vitamin C','',1),(3,'Vitamin B2','B2 helps maintain proper nerve function',1),(5,'Vitamin B12','B12',1);
/*!40000 ALTER TABLE `tbl_vitamin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_weighttype`
--

DROP TABLE IF EXISTS `tbl_weighttype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_weighttype` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Value` varchar(50) DEFAULT NULL,
  `Description` text,
  `Status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_weighttype`
--

LOCK TABLES `tbl_weighttype` WRITE;
/*!40000 ALTER TABLE `tbl_weighttype` DISABLE KEYS */;
INSERT INTO `tbl_weighttype` VALUES (1,'Gram','',1),(2,'Kilogram','',1),(3,'Number','',1),(4,'Pack','',1),(5,'Litre','This value using for liquids',1);
/*!40000 ALTER TABLE `tbl_weighttype` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-08 21:11:00
